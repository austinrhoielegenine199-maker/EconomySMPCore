package com.bx.ultimateDonutSmp.managers;

import com.bx.ultimateDonutSmp.utils.PermissionUtils;

import com.bx.ultimateDonutSmp.UltimateDonutSmp;
import com.bx.ultimateDonutSmp.menus.SpawnerMainMenu;
import com.bx.ultimateDonutSmp.menus.SpawnerPanelMenu;
import com.bx.ultimateDonutSmp.menus.SpawnerStorageMenu;
import com.bx.ultimateDonutSmp.menus.SpawnerWorldListMenu;
import com.bx.ultimateDonutSmp.models.EconomyReason;
import com.bx.ultimateDonutSmp.models.PlayerData;
import com.bx.ultimateDonutSmp.models.SellCategory;
import com.bx.ultimateDonutSmp.models.SpawnerInstance;
import com.bx.ultimateDonutSmp.models.SpawnerLootEntry;
import com.bx.ultimateDonutSmp.models.SpawnerTypeDefinition;
import com.bx.ultimateDonutSmp.models.WorthResult;
import com.bx.ultimateDonutSmp.utils.ColorUtils;
import com.bx.ultimateDonutSmp.utils.ItemUtils;
import com.bx.ultimateDonutSmp.utils.NumberUtils;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.block.Hopper;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;

public class SpawnerManager {

    public static final String SILK_TOUCH_BYPASS_PERMISSION = "ultimatedonutsmp.spawner.bypass";
    public static final String SILK_TOUCH_REQUIRED_MESSAGE = "&cYou need Silk Touch to break this spawner!";

    public record ActionResult(boolean success, String message, int consumedAmount, boolean fullyDestroyed) {
        public ActionResult(boolean success, String message, int consumedAmount) {
            this(success, message, consumedAmount, true);
        }
        public ActionResult(boolean success, String message) {
            this(success, message, 0, true);
        }
    }

    public record SellLootResult(
            boolean success,
            String message,
            double payout,
            long soldItems
    ) {}

    public record WorldSummary(String worldName, int count) {}

    private final UltimateDonutSmp plugin;
    private final NamespacedKey spawnerItemMarkerKey;
    private final NamespacedKey spawnerItemTypeKey;
    private final NamespacedKey spawnerItemAmountKey;
    private final Object lock = new Object();
    private final Map<Long, SpawnerInstance> spawnersById = new LinkedHashMap<>();
    private final Map<String, Long> locationIndex = new HashMap<>();
    private final Map<String, LinkedHashSet<Long>> worldIndex = new HashMap<>();
    private final Map<String, SpawnerTypeDefinition> typeDefinitions = new LinkedHashMap<>();
    private final AtomicLong temporarySpawnerIdSequence = new AtomicLong(-1L);
    private final Set<Long> temporarySpawnerIds = new HashSet<>();
    private final Map<Long, List<SpawnerLootEntry>> pendingLootMap = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID, SpawnerStorageMenu> openStorageMenus = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID, SpawnerMainMenu> openMainMenus = new java.util.concurrent.ConcurrentHashMap<>();
    private boolean serverWipeMode;
    private boolean enabled;
    private boolean xpEnabled;
    private SpawnerInstance.AccessMode defaultAccessMode;
    private long generationIntervalSeconds;
    private boolean processOnlyLoadedChunks;
    private boolean requirePlayerNearby;
    private double playerNearbyRadius;
    private long maxStackPerBlock;
    private long storageCapPerLootKey;
    private boolean dropOnBreakIfInventoryFull;
    private boolean allowSpawnerSteal;
    private boolean hopperExtractionEnabled;
    private int hopperExtractionAmountPerCycle;
    private boolean requireSilkTouch;
    private boolean cancelMobSpawn = true;
    private double defaultXpPerCycle;
    private String mainMenuTitle;
    private int mainMenuSize;
    private String storageTitle;
    private int storageSize;
    private int storageItemsPerPage;
    private String panelTitle;
    private int panelSize;
    private String worldListTitle;
    private int worldListSize;
    private String soundOpenMenu;
    private String soundCollectLoot;
    private String soundDropLoot;
    private String soundCollectXp;
    private String soundSellConfirmOpen;
    private String soundSellSuccess;
    private String soundSellCancel;
    private String soundFilterOpen;
    private String soundFilterToggle;

    public SpawnerManager(UltimateDonutSmp plugin) {
        this.plugin = plugin;
        this.spawnerItemMarkerKey = plugin.getKey("managed_spawner_item");
        this.spawnerItemTypeKey = plugin.getKey("managed_spawner_type");
        this.spawnerItemAmountKey = plugin.getKey("managed_spawner_amount");
        reload();
        loadPersistedSpawners();
    }

    public void reload() {
        FileConfiguration config = plugin.getConfigManager().getSpawners();
        enabled = config.getBoolean("SETTINGS.ENABLED", true);
        xpEnabled = config.getBoolean("SETTINGS.XP_ENABLED", true);
        defaultAccessMode = SpawnerInstance.AccessMode.fromString(
                config.getString("SETTINGS.ACCESS_MODE", "OWNER_ONLY"),
                SpawnerInstance.AccessMode.OWNER_ONLY
        );
        allowSpawnerSteal = config.getBoolean("SETTINGS.ALLOW_SPAWNER_STEAL",
                config.getBoolean("SETTINGS.ALLOW_STEAL",
                        config.getBoolean("SETTINGS.ALLOW_SPAWNER_STEALING", false)));
        generationIntervalSeconds = Math.max(1L, config.getLong("SETTINGS.GENERATION_INTERVAL_SECONDS", 5L));
        processOnlyLoadedChunks = config.getBoolean("SETTINGS.PROCESS_ONLY_LOADED_CHUNKS", true);
        requirePlayerNearby = config.getBoolean("SETTINGS.REQUIRE_PLAYER_NEARBY", false);
        playerNearbyRadius = Math.max(1D, config.getDouble("SETTINGS.PLAYER_NEARBY_RADIUS", 16D));
        maxStackPerBlock = Math.max(1L, config.getLong("SETTINGS.MAX_STACK_PER_BLOCK", 100_000L));
        storageCapPerLootKey = Math.max(1L, config.getLong("SETTINGS.STORAGE_CAP_PER_LOOT_KEY", 1_000_000L));
        dropOnBreakIfInventoryFull = config.getBoolean("SETTINGS.DROP_ON_BREAK_IF_INVENTORY_FULL", true);
        requireSilkTouch = config.getBoolean("SETTINGS.REQUIRE_SILK_TOUCH", true);
        cancelMobSpawn = config.getBoolean("SETTINGS.CANCEL_MOB_SPAWN", true);
        defaultXpPerCycle = Math.max(0.0, config.getDouble("SETTINGS.XP_PER_CYCLE", 3.7));
        hopperExtractionEnabled = config.getBoolean("SETTINGS.HOPPER_EXTRACTION.ENABLED", false);
        hopperExtractionAmountPerCycle = Math.max(1, config.getInt("SETTINGS.HOPPER_EXTRACTION.AMOUNT_PER_CYCLE", 64));
        FileConfiguration menusConfig = plugin.getConfigManager().getMenus();
        mainMenuTitle = menusConfig.getString("SPAWNER-MENUS.MAIN-MENU.TITLE",
                config.getString("GUI.MAIN_MENU.TITLE", "{stack} {mob}"));
        mainMenuSize = normalizeSize(menusConfig.getInt("SPAWNER-MENUS.MAIN-MENU.SIZE",
                config.getInt("GUI.MAIN_MENU.SIZE", 27)));
        storageTitle = menusConfig.getString("SPAWNER-MENUS.STORAGE-MENU.TITLE",
                config.getString("GUI.STORAGE.TITLE", "&8{mob} spawners - {page}/{max_page}"));
        storageSize = normalizeSize(menusConfig.getInt("SPAWNER-MENUS.STORAGE-MENU.SIZE",
                config.getInt("GUI.STORAGE.SIZE", 54)));
        storageItemsPerPage = Math.max(9, Math.min(storageSize - 9, menusConfig.getInt("SPAWNER-MENUS.STORAGE-MENU.ITEMS-PER-PAGE",
                config.getInt("GUI.STORAGE.ITEMS_PER_PAGE", 45))));
        panelTitle = menusConfig.getString("SPAWNER-MENUS.PANEL-MENU.TITLE",
                config.getString("GUI.PANEL.TITLE", "&8Spawners"));
        panelSize = normalizeSize(menusConfig.getInt("SPAWNER-MENUS.PANEL-MENU.SIZE",
                config.getInt("GUI.PANEL.SIZE", 54)));
        worldListTitle = menusConfig.getString("SPAWNER-MENUS.WORLD-LIST-MENU.TITLE",
                config.getString("GUI.WORLD_LIST.TITLE", "&8Spawners panel"));
        worldListSize = normalizeSize(menusConfig.getInt("SPAWNER-MENUS.WORLD-LIST-MENU.SIZE",
                config.getInt("GUI.WORLD_LIST.SIZE", 27)));
        FileConfiguration sounds = plugin.getConfigManager().getSounds();
        soundOpenMenu = sounds.getString("SPAWNERS.OPEN-MENU", "minecraft:block.chest.open|1.0|1.0");
        soundCollectLoot = sounds.getString("SPAWNERS.COLLECT-LOOT", "minecraft:entity.item.pickup|1.0|1.0");
        soundDropLoot = sounds.getString("SPAWNERS.DROP-LOOT", "minecraft:entity.item.pickup|1.0|1.2");
        soundCollectXp = sounds.getString("SPAWNERS.COLLECT-XP", "minecraft:entity.experience_orb.pickup|1.0|1.0");
        soundSellConfirmOpen = sounds.getString("SPAWNERS.SELL-CONFIRM-OPEN", "minecraft:ui.button.click|1.0|1.0");
        soundSellSuccess = sounds.getString("SPAWNERS.SELL-SUCCESS", "minecraft:entity.villager.yes|1.0|1.0");
        soundSellCancel = sounds.getString("SPAWNERS.SELL-CANCEL", "minecraft:ui.button.click|1.0|0.8");
        soundFilterOpen = sounds.getString("SPAWNERS.FILTER-OPEN", "minecraft:ui.button.click|1.0|1.2");
        soundFilterToggle = sounds.getString("SPAWNERS.FILTER-TOGGLE", "minecraft:ui.button.click|1.0|1.0");
        loadTypeDefinitions(config);

        List<SpawnerInstance> copy;
        synchronized (lock) {
            copy = new ArrayList<>(spawnersById.values());
        }
        for (SpawnerInstance instance : copy) {
            syncSpawnerBlockState(instance);
        }
    }

    private void loadPersistedSpawners() {
        synchronized (lock) {
            spawnersById.clear();
            locationIndex.clear();
            worldIndex.clear();
            temporarySpawnerIds.clear();
        }

        Map<Long, List<SpawnerLootEntry>> lootBySpawnerId = plugin.getDatabaseManager().loadAllSpawnerLoot();
        for (SpawnerInstance instance : plugin.getDatabaseManager().loadAllSpawners()) {
            instance.setStoredLootEntries(lootBySpawnerId.get(instance.getId()));
            registerSpawner(instance);
            syncSpawnerBlockState(instance);
        }
    }

    private void loadTypeDefinitions(FileConfiguration config) {
        typeDefinitions.clear();

        ConfigurationSection typesSection = config.getConfigurationSection("TYPES");
        if (typesSection == null) {
            plugin.getLogger().warning("[SpawnerManager] No TYPES section found in spawners.yml.");
            return;
        }

        for (String rawKey : typesSection.getKeys(false)) {
            ConfigurationSection section = typesSection.getConfigurationSection(rawKey);
            if (section == null || !section.getBoolean("ENABLED", true)) {
                continue;
            }

            String key = rawKey.trim().toUpperCase(Locale.US);
            EntityType entityType;
            try {
                entityType = EntityType.valueOf(section.getString("ENTITY_TYPE", key).trim().toUpperCase(Locale.US));
            } catch (Exception exception) {
                plugin.getLogger().warning("[SpawnerManager] Invalid ENTITY_TYPE for spawner type " + key + ".");
                continue;
            }

            Material iconMaterial = ItemUtils.parseMaterial(section.getString("ICON_MATERIAL", "SPAWNER"));
            long baseItemsPerCycle = Math.max(1L, section.getLong("BASE_ITEMS_PER_CYCLE", 1L));
            double xpPerCycle = Math.max(0.0, section.getDouble("XP_PER_CYCLE", defaultXpPerCycle));
            List<SpawnerTypeDefinition.DropDefinition> drops = new ArrayList<>();
            ConfigurationSection dropsSection = section.getConfigurationSection("DROPS");
            if (dropsSection != null) {
                for (String dropKey : dropsSection.getKeys(false)) {
                    ConfigurationSection dropSection = dropsSection.getConfigurationSection(dropKey);
                    if (dropSection == null || !dropSection.getBoolean("ENABLED", true)) {
                        continue;
                    }

                    Material material = ItemUtils.parseMaterial(dropSection.getString("MATERIAL", "STONE"));
                    long min = Math.max(0L, dropSection.getLong("MIN", 0L));
                    long max = Math.max(min, dropSection.getLong("MAX", min));
                    double chance = Math.max(0D, Math.min(1D, dropSection.getDouble("CHANCE", 1D)));
                    drops.add(new SpawnerTypeDefinition.DropDefinition(dropKey.toUpperCase(Locale.US), material, min, max, chance));
                }
            }

            String headTexture = section.getString("HEAD_TEXTURE", null);
            typeDefinitions.put(key, new SpawnerTypeDefinition(
                    key,
                    section.getString("DISPLAY_NAME", "&d" + prettifyKey(key) + " Spawner"),
                    entityType,
                    iconMaterial,
                    baseItemsPerCycle,
                    xpPerCycle,
                    headTexture,
                    drops
            ));
        }
    }

    public boolean isEnabled() {
        return plugin.getFeatureManager().isEnabled(FeatureManager.Feature.SPAWNERS) && enabled;
    }

    public boolean isCancelMobSpawn() {
        return cancelMobSpawn;
    }

    public boolean isRequireSilkTouch() {
        return requireSilkTouch;
    }

    public boolean hasSilkTouchAccess(Player player) {
        if (player == null) {
            return false;
        }
        if (player.getGameMode() == GameMode.CREATIVE
                || PermissionUtils.has(player, SILK_TOUCH_BYPASS_PERMISSION)) {
            return true;
        }
        ItemStack heldTool = player.getInventory().getItemInMainHand();
        return heldTool != null
                && heldTool.getType().name().endsWith("_PICKAXE")
                && heldTool.containsEnchantment(org.bukkit.enchantments.Enchantment.SILK_TOUCH);
    }

    public boolean isXpEnabled() {
        return xpEnabled;
    }

    public long getStorageCapPerLootKey() {
        return storageCapPerLootKey;
    }

    public ItemStack createSpawnerItem(String typeKey, long amount) {
        SpawnerTypeDefinition definition = getTypeDefinition(typeKey);
        if (definition == null || amount <= 0L) {
            return null;
        }

        ItemStack item = new ItemStack(Material.SPAWNER);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }

        meta.setDisplayName(ColorUtils.toComponent(definition.displayName()));
        meta.setLore(ColorUtils.toComponentList(List.of(
                "&7Type: &f" + ColorUtils.strip(definition.displayName()),
                "",
                "&ePlace to create or stack this spawner."
        )));

        PersistentDataContainer container = meta.getPersistentDataContainer();
        container.set(spawnerItemMarkerKey, PersistentDataType.BYTE, (byte) 1);
        container.set(spawnerItemTypeKey, PersistentDataType.STRING, definition.key());
        if (amount <= 64) {
            container.set(spawnerItemAmountKey, PersistentDataType.LONG, 1L);
            item.setItemMeta(meta);
            item.setAmount((int) amount);
        } else {
            container.set(spawnerItemAmountKey, PersistentDataType.LONG, amount);
            item.setItemMeta(meta);
            item.setAmount(1);
        }
        return item;
    }

    public void updateSpawnerItemAmount(ItemStack item, long newAmount) {
        if (item == null || item.getType().isAir()) {
            return;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        String typeKey = getSpawnerItemType(item);
        SpawnerTypeDefinition definition = getTypeDefinition(typeKey);
        if (definition == null) {
            return;
        }
        meta.setLore(ColorUtils.toComponentList(List.of(
                "&7Type: &f" + ColorUtils.strip(definition.displayName()),
                "",
                "&ePlace to create or stack this spawner."
        )));
        if (newAmount <= 64) {
            meta.getPersistentDataContainer().set(spawnerItemAmountKey, PersistentDataType.LONG, 1L);
            item.setItemMeta(meta);
            item.setAmount((int) newAmount);
        } else {
            meta.getPersistentDataContainer().set(spawnerItemAmountKey, PersistentDataType.LONG, newAmount);
            item.setItemMeta(meta);
            item.setAmount(1);
        }
    }

    public boolean isSpawnerItem(ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return false;
        }

        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }

        PersistentDataContainer container = meta.getPersistentDataContainer();
        Byte marker = container.get(spawnerItemMarkerKey, PersistentDataType.BYTE);
        return marker != null && marker == (byte) 1
                && container.has(spawnerItemTypeKey, PersistentDataType.STRING)
                && container.has(spawnerItemAmountKey, PersistentDataType.LONG);
    }

    public String getSpawnerItemType(ItemStack item) {
        if (!isSpawnerItem(item)) {
            return null;
        }

        ItemMeta meta = item.getItemMeta();
        return meta == null ? null : meta.getPersistentDataContainer().get(spawnerItemTypeKey, PersistentDataType.STRING);
    }

    public long getSpawnerItemBaseAmount(ItemStack item) {
        if (!isSpawnerItem(item)) {
            return 0L;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return 1L;
        }
        Long amount = meta.getPersistentDataContainer().get(spawnerItemAmountKey, PersistentDataType.LONG);
        return amount == null ? 1L : Math.max(1L, amount);
    }

    public long getSpawnerItemAmount(ItemStack item) {
        if (!isSpawnerItem(item)) {
            return 0L;
        }

        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return 0L;
        }

        long baseAmount = getSpawnerItemBaseAmount(item);
        return baseAmount * item.getAmount();
    }

    public SpawnerTypeDefinition getTypeDefinition(String typeKey) {
        if (typeKey == null || typeKey.isBlank()) {
            return null;
        }
        return typeDefinitions.get(typeKey.trim().toUpperCase(Locale.US));
    }

    public Collection<SpawnerTypeDefinition> getTypeDefinitions() {
        return List.copyOf(typeDefinitions.values());
    }

    public String getTypeDisplayName(String typeKey) {
        SpawnerTypeDefinition definition = getTypeDefinition(typeKey);
        return definition == null ? "&dspawner" : definition.displayName();
    }

    public String getPlainTypeDisplayName(String typeKey) {
        return ColorUtils.strip(getTypeDisplayName(typeKey));
    }

    public String getSilkTouchRequiredMessage() {
        return getMessage("SILK-TOUCH-REQUIRED", SILK_TOUCH_REQUIRED_MESSAGE);
    }

    public String getMessage(String path, String fallback, Object... placeholders) {
        if (plugin == null || plugin.getConfigManager() == null) {
            return formatMessage(fallback, placeholders);
        }
        FileConfiguration config = plugin.getConfigManager().getSpawners();
        String text = config != null ? config.getString("MESSAGES." + path, fallback) : fallback;
        if (text == null) {
            text = fallback != null ? fallback : "";
        }
        return formatMessage(text, placeholders);
    }

    public List<String> getMessageList(String path, List<String> fallback, Object... placeholders) {
        if (plugin == null || plugin.getConfigManager() == null) {
            return formatMessageList(fallback, placeholders);
        }
        FileConfiguration config = plugin.getConfigManager().getSpawners();
        List<String> list = config != null ? config.getStringList("MESSAGES." + path) : null;
        if (list == null || list.isEmpty()) {
            list = fallback != null ? fallback : List.of();
        }
        return formatMessageList(list, placeholders);
    }

    private static String formatMessage(String text, Object... placeholders) {
        String output = text == null ? "" : text;
        for (int index = 0; index + 1 < placeholders.length; index += 2) {
            String key = String.valueOf(placeholders[index]);
            String val = placeholders[index + 1] != null ? String.valueOf(placeholders[index + 1]) : "";
            output = output.replace(key, val);
            if (!key.startsWith("{") || !key.endsWith("}")) {
                output = output.replace("{" + key + "}", val);
            }
        }
        return output;
    }

    private static List<String> formatMessageList(List<String> list, Object... placeholders) {
        if (list == null) {
            return List.of();
        }
        return list.stream().map(line -> formatMessage(line, placeholders)).toList();
    }

    public ActionResult giveSpawner(Player target, String typeKey, long amount) {
        if (!enabled) {
            return fail(getMessage("DISABLED", "&cspawner system is currently disabled."));
        }
        if (target == null) {
            return fail(getMessage("TARGET-NOT-ONLINE", "&ctarget player must be online."));
        }
        if (amount <= 0L) {
            return fail(getMessage("AMOUNT-POSITIVE", "&cspawner amount must be positive."));
        }

        SpawnerTypeDefinition definition = getTypeDefinition(typeKey);
        if (definition == null) {
            return fail(getMessage("UNKNOWN-TYPE", "&cunknown spawner type '&f{type}&c'.", "{type}", typeKey));
        }

        long remaining = amount;
        while (remaining > 0) {
            int stackSize = (int) Math.min(64, remaining);
            ItemStack item = createSpawnerItem(definition.key(), stackSize);
            if (item == null) {
                return fail(getMessage("CREATE-ITEM-FAILED", "&cfailed to create the spawner item."));
            }
            Map<Integer, ItemStack> leftovers = target.getInventory().addItem(item);
            leftovers.values().forEach(leftover -> target.getWorld().dropItemNaturally(target.getLocation(), leftover));
            remaining -= stackSize;
        }
        return ok(getMessage("GAVE-SPAWNER", "&aGave &f{amount}x {type}&a to &f{player}&a.",
                "{amount}", NumberUtils.format(amount),
                "{type}", ColorUtils.strip(definition.displayName()),
                "{player}", target.getName()));
    }

    public ActionResult placeSpawner(Player player, Block block, ItemStack item) {
        if (!enabled) {
            return fail(getMessage("DISABLED", "&cspawner system is currently disabled."));
        }
        if (player == null || block == null || !isSpawnerItem(item)) {
            return fail(getMessage("NOT-SPAWNER-ITEM", "&cthat is not a managed spawner item."));
        }

        String typeKey = getSpawnerItemType(item);
        long baseAmount = getSpawnerItemBaseAmount(item);
        
        boolean stackAll = player.isSneaking();
        int quantity = stackAll ? item.getAmount() : 1;
        long amount = baseAmount * quantity;

        if (amount <= 0L) {
            return fail(getMessage("INVALID-AMOUNT", "&cthis spawner item has an invalid amount."));
        }
        if (amount > maxStackPerBlock) {
            return fail(getMessage("MAX-STACK-EXCEEDED", "&cthat would exceed the max stack per block (&f{max}&c).",
                    "{max}", NumberUtils.format(maxStackPerBlock)));
        }

        if (getSpawner(block) != null) {
            return fail(getMessage("ALREADY-SPAWNER", "&cthat block is already a managed spawner."));
        }

        SpawnerTypeDefinition definition = getTypeDefinition(typeKey);
        if (definition == null) {
            return fail(getMessage("UNKNOWN-TYPE", "&cunknown spawner type '&f{type}&c'.", "{type}", typeKey));
        }

        long now = System.currentTimeMillis();
        SpawnerInstance instance = new SpawnerInstance(
                0L,
                block.getWorld().getName(),
                block.getX(),
                block.getY(),
                block.getZ(),
                player.getUniqueId(),
                player.getName(),
                definition.key(),
                amount,
                defaultAccessMode,
                now,
                now,
                now
        );

        long id = plugin.getDatabaseManager().createSpawner(instance);
        if (id <= 0L) {
            return fail(getMessage("SAVE-FAILED", "&cfailed to save that spawner. please try again."));
        }

        instance.setId(id);
        registerSpawner(instance);

        String spawnerName = ColorUtils.strip(definition.displayName());
        plugin.getPlayerLogsManager().log(
                player.getUniqueId(),
                player.getName(),
                "Spawners",
                "SPAWNER_PLACE",
                "Placed " + instance.getStackAmount() + "x " + spawnerName + " spawner at "
                        + block.getWorld().getName() + " " + block.getX() + ", " + block.getY() + ", " + block.getZ()
        );

        plugin.getSpigotScheduler().runRegion(block.getLocation(), () -> {
            syncSpawnerBlockStateImmediate(instance);
        });

        return new ActionResult(
                true,
                getMessage("PLACED", "&aplaced &f{amount}x {type}&a.",
                        "{amount}", NumberUtils.format(instance.getStackAmount()),
                        "{type}", ColorUtils.strip(definition.displayName())),
                quantity
        );
    }

    public ActionResult createTemporarySpawner(Player owner, Block block, String typeKey, long amount, SpawnerInstance.AccessMode accessMode) {
        if (!enabled) {
            return fail(getMessage("DISABLED", "&cspawner system is currently disabled."));
        }
        if (owner == null || block == null) {
            return fail(getMessage("TEMP-NEEDS-PLAYER-BLOCK", "&ctemporary spawner needs a player and block."));
        }
        if (getSpawner(block) != null) {
            return fail(getMessage("ALREADY-SPAWNER", "&cthat block is already a managed spawner."));
        }

        SpawnerTypeDefinition definition = getTypeDefinition(typeKey);
        if (definition == null) {
            return fail(getMessage("UNKNOWN-TYPE", "&cunknown spawner type '&f{type}&c'.", "{type}", typeKey));
        }

        long now = System.currentTimeMillis();
        SpawnerInstance instance = new SpawnerInstance(
                temporarySpawnerIdSequence.getAndDecrement(),
                block.getWorld().getName(),
                block.getX(),
                block.getY(),
                block.getZ(),
                owner.getUniqueId(),
                owner.getName(),
                definition.key(),
                Math.max(1L, amount),
                accessMode == null ? SpawnerInstance.AccessMode.PUBLIC : accessMode,
                now,
                now,
                now
        );

        registerSpawner(instance);
        synchronized (lock) {
            temporarySpawnerIds.add(instance.getId());
        }
        syncSpawnerBlockStateImmediate(instance);
        return ok(getMessage("TEMP-REGISTERED", "&atemporary spawner registered."));
    }

    public boolean isTemporarySpawner(SpawnerInstance instance) {
        if (instance == null) {
            return false;
        }
        synchronized (lock) {
            return temporarySpawnerIds.contains(instance.getId());
        }
    }

    public boolean removeTemporarySpawner(Block block) {
        SpawnerInstance instance = getSpawner(block);
        if (!isTemporarySpawner(instance)) {
            return false;
        }

        unregisterSpawner(instance);
        synchronized (lock) {
            temporarySpawnerIds.remove(instance.getId());
        }
        return true;
    }

    public ActionResult stackSpawner(Player player, Block block, ItemStack item) {
        if (!enabled) {
            return fail(getMessage("DISABLED", "&cspawner system is currently disabled."));
        }
        SpawnerInstance existing = getSpawner(block);
        if (existing == null) {
            return fail(getMessage("NOT-MANAGED-SPAWNER", "&cthat is not a managed spawner."));
        }
        if (isTemporarySpawner(existing)) {
            return fail(getMessage("TEMP-CANNOT-STACK", "&ctemporary spawners cannot be stacked."));
        }
        if (!isSpawnerItem(item)) {
            return fail(getMessage("HOLD-TO-STACK", "&chold a managed spawner item to stack."));
        }
        if (!canModify(player, existing)) {
            return fail(getMessage("NOT-OWNER", "&cyou do not own that spawner."));
        }

        String typeKey = Objects.requireNonNullElse(getSpawnerItemType(item), "");
        if (!existing.getMobTypeKey().equalsIgnoreCase(typeKey)) {
            return fail(getMessage("TYPE-MISMATCH", "&cyou can only stack the same spawner type onto this block."));
        }

        long baseAmount = getSpawnerItemBaseAmount(item);
        if (baseAmount <= 0L) {
            return fail(getMessage("INVALID-AMOUNT", "&cthis spawner item has an invalid amount."));
        }

        long remainingCapacity = maxStackPerBlock - existing.getStackAmount();
        if (remainingCapacity <= 0L) {
            return fail(getMessage("ALREADY-AT-MAX-STACK", "&cthat spawner is already at the max stack per block (&f{max}&c).",
                    "{max}", NumberUtils.format(maxStackPerBlock)));
        }

        boolean stackAll = player.isSneaking();
        long maxUnitsCanAdd = Math.max(1L, remainingCapacity / baseAmount);
        int quantity = stackAll ? (int) Math.min(item.getAmount(), maxUnitsCanAdd) : 1;
        long addAmount = baseAmount * quantity;

        if (addAmount <= 0L) {
            return fail(getMessage("INVALID-AMOUNT", "&cthis spawner item has an invalid amount."));
        }

        long targetAmount = existing.getStackAmount() + addAmount;
        if (targetAmount > maxStackPerBlock) {
            return fail(getMessage("MAX-STACK-EXCEEDED", "&cthat would exceed the max stack per block (&f{max}&c).",
                    "{max}", NumberUtils.format(maxStackPerBlock)));
        }

        existing.setStackAmount(targetAmount);
        existing.setUpdatedAt(System.currentTimeMillis());
        saveSpawnerAsync(existing);
        plugin.getSpigotScheduler().runRegion(block.getLocation(), () -> {
            syncSpawnerBlockStateImmediate(existing);
        });

        return new ActionResult(true, getMessage("STACKED", "&aspawner stack updated to &f{amount}&a.",
                "{amount}", NumberUtils.format(existing.getStackAmount())), quantity);
    }

    public SpawnerInstance getSpawner(Block block) {
        if (block == null) {
            return null;
        }
        return getSpawner(block.getWorld().getName(), block.getX(), block.getY(), block.getZ());
    }

    public SpawnerInstance getSpawner(String world, int x, int y, int z) {
        synchronized (lock) {
            Long id = locationIndex.get(SpawnerInstance.buildLocationKey(world, x, y, z));
            return id == null ? null : spawnersById.get(id);
        }
    }

    public SpawnerInstance getSpawner(long spawnerId) {
        synchronized (lock) {
            return spawnersById.get(spawnerId);
        }
    }

    public Collection<SpawnerInstance> getAllSpawners() {
        synchronized (lock) {
            return List.copyOf(spawnersById.values());
        }
    }

    public List<SpawnerInstance> getSpawnersInWorld(String worldName) {
        synchronized (lock) {
            LinkedHashSet<Long> ids = worldIndex.get(worldName == null ? "" : worldName.toLowerCase(Locale.US));
            if (ids == null || ids.isEmpty()) {
                return List.of();
            }

            List<SpawnerInstance> spawners = new ArrayList<>();
            for (Long id : ids) {
                SpawnerInstance instance = spawnersById.get(id);
                if (instance != null) {
                    spawners.add(instance);
                }
            }
            spawners.sort(Comparator.comparingLong(SpawnerInstance::getStackAmount).reversed()
                    .thenComparingInt(SpawnerInstance::getX));
            return spawners;
        }
    }

    public boolean isNearManagedSpawner(Location loc, double maxDistance) {
        if (loc == null || loc.getWorld() == null) {
            return false;
        }
        double maxDistSq = maxDistance * maxDistance;
        List<SpawnerInstance> inWorld = getSpawnersInWorld(loc.getWorld().getName());
        for (SpawnerInstance instance : inWorld) {
            double dx = instance.getX() + 0.5D - loc.getX();
            double dy = instance.getY() + 0.5D - loc.getY();
            double dz = instance.getZ() + 0.5D - loc.getZ();
            if ((dx * dx + dy * dy + dz * dz) <= maxDistSq) {
                return true;
            }
        }
        return false;
    }

    public List<WorldSummary> getWorldSummaries() {
        List<WorldSummary> summaries = new ArrayList<>();
        for (World world : Bukkit.getWorlds()) {
            summaries.add(new WorldSummary(world.getName(), getSpawnersInWorld(world.getName()).size()));
        }
        summaries.sort(Comparator
                .comparingInt((WorldSummary summary) -> getWorldSortIndex(summary.worldName()))
                .thenComparing(summary -> describeWorld(summary.worldName()), String.CASE_INSENSITIVE_ORDER));
        return summaries;
    }

    public void playSound(Player player, String soundConfig) {
        if (player != null && soundConfig != null && !soundConfig.isBlank()) {
            com.bx.ultimateDonutSmp.utils.SoundUtils.play(player, soundConfig);
        }
    }

    public void playOpenMenuSound(Player player) { playSound(player, soundOpenMenu); }
    public void playCollectLootSound(Player player) { playSound(player, soundCollectLoot); }
    public void playDropLootSound(Player player) { playSound(player, soundDropLoot); }
    public void playCollectXpSound(Player player) { playSound(player, soundCollectXp); }
    public void playSellConfirmOpenSound(Player player) { playSound(player, soundSellConfirmOpen); }
    public void playSellSuccessSound(Player player) { playSound(player, soundSellSuccess); }
    public void playSellCancelSound(Player player) { playSound(player, soundSellCancel); }
    public void playFilterOpenSound(Player player) { playSound(player, soundFilterOpen); }
    public void playFilterToggleSound(Player player) { playSound(player, soundFilterToggle); }

    public void openStorage(Player player, SpawnerInstance instance, int page) {
        if (player == null || instance == null) {
            return;
        }
        playOpenMenuSound(player);
        new SpawnerStorageMenu(plugin, instance.getId(), page).open(player);
    }

    public void openMainMenu(Player player, SpawnerInstance instance) {
        if (player == null || instance == null) {
            return;
        }
        playOpenMenuSound(player);
        new com.bx.ultimateDonutSmp.menus.SpawnerMainMenu(plugin, instance.getId()).open(player);
    }

    public String getMainMenuTitle(SpawnerInstance instance) {
        if (instance == null) {
            return "&8Spawner";
        }
        String cleanMob = prettifyKey(instance.getMobTypeKey());
        String title = mainMenuTitle
                .replace("{mob}", cleanMob)
                .replace("{stack}", String.valueOf(instance.getStackAmount()));

        if (!ColorUtils.strip(title).toLowerCase(Locale.US).endsWith("spawner")) {
            title = title + " Spawner";
        }
        title = title.replaceAll("(?i)\\bspawners?\\s+spawners?\\b", "Spawner");
        return title;
    }

    public int getMainMenuSize() {
        return mainMenuSize;
    }

    public void openPanel(Player player) {
        if (player == null) {
            return;
        }
        new SpawnerWorldListMenu(plugin).open(player);
    }

    public void openWorldPanel(Player player, String worldName, int page) {
        if (player == null) {
            return;
        }
        new SpawnerPanelMenu(plugin, worldName, page).open(player);
    }

    public ActionResult breakSpawner(Player player, Block block) {
        SpawnerInstance instance = getSpawner(block);
        if (isTemporarySpawner(instance)) {
            unregisterSpawner(instance);
            temporarySpawnerIds.remove(instance.getId());
            return new ActionResult(true, getMessage("TEMP-REMOVED", "&atemporary spawner removed."), 0, true);
        }
        if (instance == null) {
            return fail(getMessage("NOT-MANAGED-SPAWNER", "&cthat is not a managed spawner."));
        }
        if (!canBreak(player, instance)) {
            return fail(getMessage("NO-BREAK-PERMISSION", "&cyou do not have permission to break that spawner."));
        }

        if (requireSilkTouch && !hasSilkTouchAccess(player)) {
            return fail(getSilkTouchRequiredMessage());
        }

        long totalStack = instance.getStackAmount();
        boolean stackAll = player != null && player.isSneaking();
        long breakAmount = stackAll ? Math.min(64L, totalStack) : 1L;
        long remainingStack = totalStack - breakAmount;

        boolean fullyDestroyed;
        if (remainingStack <= 0L) {
            unregisterSpawner(instance);
            deleteSpawnerAsync(instance.getId());
            fullyDestroyed = true;
        } else {
            instance.setStackAmount(remainingStack);
            instance.setUpdatedAt(System.currentTimeMillis());
            saveSpawnerAsync(instance);
            plugin.getSpigotScheduler().runRegion(block.getLocation(), () -> {
                syncSpawnerBlockStateImmediate(instance);
            });
            fullyDestroyed = false;
        }

        String spawnerName = getPlainTypeDisplayName(instance.getMobTypeKey());
        if (player != null) {
            plugin.getPlayerLogsManager().log(
                    player.getUniqueId(),
                    player.getName(),
                    "Spawners",
                    "SPAWNER_BREAK",
                    "Broke " + breakAmount + "x " + spawnerName + " spawner (Remaining: " + remainingStack + "x) at "
                            + block.getWorld().getName() + " " + block.getX() + ", " + block.getY() + ", " + block.getZ()
            );
        }

        boolean returnedItem = player != null && returnsSpawnerItemOnBreak(player.getGameMode());
        if (returnedItem) {
            long remaining = breakAmount;
            List<ItemStack> itemsToGive = new ArrayList<>();
            while (remaining > 0) {
                int amount = (int) Math.min(64, remaining);
                ItemStack item = createSpawnerItem(instance.getMobTypeKey(), amount);
                if (item != null) {
                    itemsToGive.add(item);
                }
                remaining -= amount;
            }

            PlayerInventory inventory = player.getInventory();
            for (ItemStack item : itemsToGive) {
                Map<Integer, ItemStack> leftovers = inventory.addItem(item);
                if (dropOnBreakIfInventoryFull) {
                    leftovers.values().forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), leftover));
                } else if (!leftovers.isEmpty()) {
                    leftovers.values().forEach(leftover -> inventory.addItem(leftover));
                }
            }
        }

        String msg = returnedItem
                ? getMessage("PICKED-UP", "&apicked up &f{amount}x {type}&a.",
                        "{amount}", NumberUtils.format(breakAmount),
                        "{type}", spawnerName)
                : getMessage("REMOVED", "&aremoved &f{amount}x {type}&a.",
                        "{amount}", NumberUtils.format(breakAmount),
                        "{type}", spawnerName);
        return new ActionResult(true, msg, (int) breakAmount, fullyDestroyed);
    }

    public ActionResult collectLootEntry(Player player, SpawnerInstance instance, String lootKey, boolean collectAll) {
        if (player == null || instance == null) {
            return fail(getMessage("NOT-FOUND", "&cspawner not found."));
        }
        if (!canOpen(player, instance)) {
            return fail(getMessage("NO-ACCESS", "&cyou do not have access to that spawner."));
        }

        SpawnerLootEntry entry = instance.getStoredLoot(lootKey);
        if (entry == null || entry.getAmount() <= 0L) {
            return fail(getMessage("LOOT-EMPTY", "&cthat loot entry is empty."));
        }

        long requested = collectAll ? entry.getAmount() : Math.min(entry.getAmount(), entry.getMaterial().getMaxStackSize());
        long moved = moveMaterialToInventory(player.getInventory(), entry.getMaterial(), requested);
        if (moved <= 0L) {
            return fail(getMessage("INVENTORY-FULL", "&cyour inventory is full."));
        }

        instance.removeStoredLoot(entry.getKey(), moved);
        instance.setUpdatedAt(System.currentTimeMillis());
        saveLoot(instance);
        playCollectLootSound(player);
        return ok(getMessage("COLLECTED", "&acollected &f{amount}x {item}&a.",
                "{amount}", NumberUtils.format(moved),
                "{item}", plugin.getWorthManager().prettifyMaterial(entry.getMaterial())));
    }

    public ActionResult collectAllLoot(Player player, SpawnerInstance instance) {
        if (player == null || instance == null) {
            return fail(getMessage("NOT-FOUND", "&cspawner not found."));
        }
        if (!canOpen(player, instance)) {
            return fail(getMessage("NO-ACCESS", "&cyou do not have access to that spawner."));
        }

        long totalMoved = 0L;
        for (SpawnerLootEntry entry : new ArrayList<>(instance.getStoredLootEntries())) {
            long moved = moveMaterialToInventory(player.getInventory(), entry.getMaterial(), entry.getAmount());
            if (moved <= 0L) {
                continue;
            }

            instance.removeStoredLoot(entry.getKey(), moved);
            totalMoved += moved;
        }

        if (totalMoved <= 0L) {
            return fail(getMessage("NO-SPACE", "&cthere was no space to collect your spawner loot."));
        }

        instance.setUpdatedAt(System.currentTimeMillis());
        saveLoot(instance);
        playCollectLootSound(player);
        return ok(getMessage("COLLECTED-ALL", "&acollected &f{amount}&a items from this spawner.",
                "{amount}", NumberUtils.format(totalMoved)));
    }

    public ActionResult dropPageLoot(Player player, SpawnerInstance instance, int page) {
        if (player == null || instance == null) {
            return fail(getMessage("NOT-FOUND", "&cspawner not found."));
        }
        if (!canOpen(player, instance)) {
            return fail(getMessage("NO-ACCESS", "&cyou do not have access to that spawner."));
        }

        Location dropLocation = getSpawnerCenter(instance).add(0, 0.5D, 0);
        long dropped = 0L;
        for (SpawnerLootEntry entry : instance.getPageLootEntries(page, storageItemsPerPage)) {
            long droppedForEntry = dropMaterial(player, dropLocation, entry.getMaterial(), entry.getAmount());
            if (droppedForEntry > 0L) {
                instance.removeStoredLoot(entry.getKey(), droppedForEntry);
                dropped += droppedForEntry;
            }
        }

        if (dropped <= 0L) {
            return fail(getMessage("NO-LOOT-ON-PAGE", "&cthere is no loot stored on this page."));
        }

        instance.setUpdatedAt(System.currentTimeMillis());
        saveLoot(instance);
        playDropLootSound(player);
        return ok(getMessage("DROPPED-PAGE", "&adropped &f{amount}&a stored items from this page on the ground.",
                "{amount}", NumberUtils.format(dropped)));
    }

    public record SpawnerSellPreview(double totalPayout, long totalSellableItems, double maxMultiplier) {}

    public SpawnerSellPreview calculateLootSellPreview(Player player, SpawnerInstance instance) {
        if (player == null || instance == null) {
            return new SpawnerSellPreview(0D, 0L, 1.0D);
        }

        Map<SellCategory, Double> progress = new EnumMap<>(SellCategory.class);
        progress.putAll(plugin.getShopManager().getSellProgress(player.getUniqueId()));

        double totalPayout = 0D;
        long soldItems = 0L;
        double maxMultiplier = 1.0D;
        boolean foundCategory = false;

        for (SpawnerLootEntry entry : new ArrayList<>(instance.getStoredLootEntries())) {
            if (entry.getAmount() <= 0) {
                continue;
            }
            ItemStack single = new ItemStack(entry.getMaterial(), 1);
            WorthResult worthResult = plugin.getWorthManager().resolveWorth(single);
            if (!worthResult.sellable()) {
                continue;
            }

            SellCategory category = plugin.getShopManager().getSellCategory(single);
            if (category == null) {
                continue;
            }

            double unitWorth = worthResult.unitWorth();
            double baseTotal = unitWorth * entry.getAmount();
            double multiplier = plugin.getShopManager().getCurrentSellMultiplier(progress, category);
            double payout = baseTotal * multiplier;

            totalPayout += payout;
            soldItems += entry.getAmount();
            if (!foundCategory || multiplier > maxMultiplier) {
                maxMultiplier = multiplier;
                foundCategory = true;
            }
        }

        if (!foundCategory) {
            maxMultiplier = plugin.getShopManager().getCurrentSellMultiplier(progress, SellCategory.MOBS);
        }

        return new SpawnerSellPreview(totalPayout, soldItems, maxMultiplier);
    }

    public SellLootResult sellAllLoot(Player player, SpawnerInstance instance) {
        if (player == null || instance == null) {
            return failSell(getMessage("NOT-FOUND", "&cspawner not found."));
        }
        if (!canOpen(player, instance)) {
            return failSell(getMessage("NO-ACCESS", "&cyou do not have access to that spawner."));
        }

        Map<SellCategory, Double> progress = new EnumMap<>(SellCategory.class);
        progress.putAll(plugin.getShopManager().getSellProgress(player.getUniqueId()));

        Map<SellCategory, Double> earnedByCategory = new EnumMap<>(SellCategory.class);
        double totalPayout = 0D;
        long soldItems = 0L;

        List<DatabaseManager.SellHistoryRecord> historyRecords = new ArrayList<>();

        for (SpawnerLootEntry entry : new ArrayList<>(instance.getStoredLootEntries())) {
            ItemStack single = new ItemStack(entry.getMaterial(), 1);
            WorthResult worthResult = plugin.getWorthManager().resolveWorth(single);
            if (!worthResult.sellable()) {
                continue;
            }

            SellCategory category = plugin.getShopManager().getSellCategory(single);
            if (category == null) {
                continue;
            }

            double unitWorth = worthResult.unitWorth();
            double baseTotal = unitWorth * entry.getAmount();
            double multiplier = plugin.getShopManager().getCurrentSellMultiplier(progress, category);
            double payout = baseTotal * multiplier;
            totalPayout += payout;
            soldItems += entry.getAmount();
            earnedByCategory.merge(category, baseTotal, Double::sum);

            int historyAmount = (int) Math.min(Integer.MAX_VALUE, entry.getAmount());
            historyRecords.add(new DatabaseManager.SellHistoryRecord(player.getUniqueId(), entry.getMaterial().name(), historyAmount, payout));
            instance.removeStoredLoot(entry.getKey(), entry.getAmount());
        }

        if (totalPayout <= 0D || soldItems <= 0L) {
            return failSell(getMessage("NO-SELLABLE-ITEMS", "&cthere are no sellable items stored in that spawner."));
        }

        Map<SellCategory, Double> earnedCopy = new EnumMap<>(earnedByCategory);
        plugin.getDatabaseManager().executeAsync(() -> {
            plugin.getDatabaseManager().addSellHistoryBatch(historyRecords);
            for (Map.Entry<SellCategory, Double> progressEntry : earnedCopy.entrySet()) {
                plugin.getDatabaseManager().addSellProgress(player.getUniqueId(), progressEntry.getKey(), progressEntry.getValue());
            }
        });

        var depositResult = plugin.getEconomyManager().deposit(player, totalPayout, EconomyReason.SELL_PAYOUT);
        if (!depositResult.success()) {
            return failSell(getMessage("SELL-FAILED", "&cfailed to pay out the spawner loot sale."));
        }

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data != null) {
            data.addMoneyMade(totalPayout);
        }

        instance.setUpdatedAt(System.currentTimeMillis());
        saveLoot(instance);
        playSellSuccessSound(player);
        return new SellLootResult(
                true,
                getMessage("SOLD", "&asold &f{amount}&a items for {price}&a.",
                        "{amount}", NumberUtils.format(soldItems),
                        "{price}", plugin.getCurrencyManager().formatMoneyCompact(totalPayout)),
                totalPayout,
                soldItems
        );
    }

    public ActionResult collectXp(Player player, SpawnerInstance instance) {
        if (!xpEnabled) {
            return fail(getMessage("XP-DISABLED", "&cXP collection is disabled on this server."));
        }
        if (player == null || instance == null) {
            return fail(getMessage("NOT-FOUND", "&cspawner not found."));
        }
        if (!canOpen(player, instance)) {
            return fail(getMessage("NO-ACCESS", "&cyou do not have access to that spawner."));
        }

        double xp = instance.getStoredXp();
        if (xp <= 0.0) {
            return fail(getMessage("NO-XP-STORED", "&cthere is no XP stored in that spawner."));
        }

        instance.setStoredXp(0.0);
        instance.setUpdatedAt(System.currentTimeMillis());
        if (!isTemporarySpawner(instance)) {
            saveSpawnerAsync(instance);
        }

        int xpPoints = (int) Math.round(xp);
        player.giveExp(xpPoints);

        playCollectXpSound(player);
        return ok(getMessage("COLLECTED-XP", "&acollected &f{amount} &aXP points!",
                "{amount}", String.format(Locale.US, "%.1f", xp)));
    }

    public ActionResult sellAndCollectXp(Player player, SpawnerInstance instance) {
        if (player == null || instance == null) {
            return fail(getMessage("NOT-FOUND", "&cspawner not found."));
        }
        if (!canOpen(player, instance)) {
            return fail(getMessage("NO-ACCESS", "&cyou do not have access to that spawner."));
        }

        SellLootResult sellResult = sellAllLoot(player, instance);
        ActionResult xpResult = xpEnabled ? collectXp(player, instance) : fail("");

        if (!sellResult.success() && (!xpEnabled || !xpResult.success())) {
            return fail(getMessage("NO-SELLABLE-ITEMS", "&cthere are no sellable items stored in that spawner."));
        }

        String msg = "";
        if (sellResult.success()) {
            msg += sellResult.message();
        }
        if (xpResult.success()) {
            if (!msg.isBlank()) {
                msg += " ";
            }
            msg += xpResult.message();
        }

        return ok(msg);
    }

    public ActionResult removeSpawner(SpawnerInstance instance, boolean dropItem, Player actor) {
        if (instance == null) {
            return fail(getMessage("NOT-FOUND", "&cspawner not found."));
        }
        if (isTemporarySpawner(instance)) {
            temporarySpawnerIds.remove(instance.getId());
            unregisterSpawner(instance);
            return ok(getMessage("TEMP-REMOVED", "&atemporary spawner removed."));
        }

        unregisterSpawner(instance);
        deleteSpawnerAsync(instance.getId());
        World world = Bukkit.getWorld(instance.getWorld());
        if (world != null && dropItem) {
            long remaining = instance.getStackAmount();
            while (remaining > 0) {
                int amount = (int) Math.min(64, remaining);
                ItemStack item = createSpawnerItem(instance.getMobTypeKey(), amount);
                if (item != null) {
                    world.dropItemNaturally(getSpawnerCenter(instance), item);
                }
                remaining -= amount;
            }
        }

        return ok(getMessage("REMOVED-ADMIN", "&aspawner removed."));
    }

    public void processGeneration() {
        if (!enabled) {
            return;
        }

        List<SpawnerInstance> copy;
        synchronized (lock) {
            if (spawnersById.isEmpty()) {
                return;
            }
            copy = new ArrayList<>(spawnersById.values());
        }

        long now = System.currentTimeMillis();
        long intervalMillis = generationIntervalSeconds * 1000L;
        if (intervalMillis <= 0L) {
            return;
        }

        for (SpawnerInstance instance : copy) {
            try {
                Location loc = getSpawnerCenter(instance);
                plugin.getSpigotScheduler().runRegion(loc, () -> {
                    try {
                        processSpawnerGeneration(instance, now, intervalMillis);
                    } catch (Exception exception) {
                        plugin.getLogger().log(Level.WARNING,
                                "Failed to process spawner generation for " + instance.getLocationKey(), exception);
                    }
                });
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING,
                        "Failed to schedule spawner generation for " + instance.getLocationKey(), exception);
            }
        }
        refreshOpenStorageMenus();
    }

    public void registerOpenStorageMenu(Player player, SpawnerStorageMenu menu) {
        if (player == null || menu == null) {
            return;
        }
        openStorageMenus.put(player.getUniqueId(), menu);
    }

    public void unregisterOpenStorageMenu(Player player, SpawnerStorageMenu menu) {
        if (player == null || menu == null) {
            return;
        }
        openStorageMenus.remove(player.getUniqueId(), menu);
    }

    public void refreshOpenStorageMenus() {
        if (openStorageMenus.isEmpty()) {
            return;
        }

        // this runs on the global/generation thread, so look the menus up from our own
        // registry instead of asking every open inventory for its holder: block backed
        // inventories (shulker box, chest, ...) read the world to answer that, which
        // Folia refuses outside the region owning the block.
        for (Map.Entry<UUID, SpawnerStorageMenu> entry : openStorageMenus.entrySet()) {
            Player player = Bukkit.getPlayer(entry.getKey());
            if (player == null || !player.isOnline()) {
                openStorageMenus.remove(entry.getKey(), entry.getValue());
                continue;
            }

            SpawnerStorageMenu menu = entry.getValue();
            plugin.getSpigotScheduler().runEntity(player, () -> {
                if (player.isOnline()) {
                    menu.refresh(player);
                }
            });
        }
    }

    public void registerOpenMainMenu(Player player, SpawnerMainMenu menu) {
        if (player == null || menu == null) {
            return;
        }
        openMainMenus.put(player.getUniqueId(), menu);
    }

    public void unregisterOpenMainMenu(Player player, SpawnerMainMenu menu) {
        if (player == null || menu == null) {
            return;
        }
        openMainMenus.remove(player.getUniqueId(), menu);
    }

    public void refreshOpenMainMenus() {
        if (openMainMenus.isEmpty()) {
            return;
        }

        for (Map.Entry<UUID, SpawnerMainMenu> entry : openMainMenus.entrySet()) {
            Player player = Bukkit.getPlayer(entry.getKey());
            if (player == null || !player.isOnline()) {
                openMainMenus.remove(entry.getKey(), entry.getValue());
                continue;
            }

            SpawnerMainMenu menu = entry.getValue();
            plugin.getSpigotScheduler().runEntity(player, () -> {
                if (player.isOnline()) {
                    menu.refresh(player);
                }
            });
        }
    }

    public long getTotalStorageCapacity(SpawnerInstance instance) {
        if (instance == null) {
            return storageCapPerLootKey;
        }
        SpawnerTypeDefinition def = getTypeDefinition(instance.getMobTypeKey());
        return calculateTotalStorageCapacity(def, instance.getDisabledLootKeys(), storageCapPerLootKey);
    }

    public static long calculateTotalStorageCapacity(SpawnerTypeDefinition def, Set<String> disabledKeys, long storageCapPerLootKey) {
        long baseCap = Math.max(1L, storageCapPerLootKey);
        if (def == null || def.drops().isEmpty()) {
            return baseCap;
        }
        long enabledCount = def.drops().stream()
                .filter(drop -> disabledKeys == null || (!disabledKeys.contains(drop.key().toUpperCase(Locale.US))
                        && !disabledKeys.contains(drop.material().name())))
                .count();
        if (enabledCount <= 0L) {
            enabledCount = def.drops().size();
        }
        return enabledCount * baseCap;
    }

    private void processSpawnerGeneration(SpawnerInstance instance, long now, long intervalMillis) {
        SpawnerTypeDefinition definition = getTypeDefinition(instance.getMobTypeKey());
        if (definition == null) {
            return;
        }

        World world = Bukkit.getWorld(instance.getWorld());
        if (world == null) {
            return;
        }

        int chunkX = instance.getX() >> 4;
        int chunkZ = instance.getZ() >> 4;
        if (processOnlyLoadedChunks && !world.isChunkLoaded(chunkX, chunkZ)) {
            return;
        }
        if (requirePlayerNearby && !hasNearbyPlayer(world, instance, playerNearbyRadius)) {
            return;
        }

        Block block = world.getBlockAt(instance.getX(), instance.getY(), instance.getZ());
        if (block.getType() != Material.SPAWNER) {
            return;
        }

        if (hopperExtractionEnabled) {
            tryHopperExtraction(instance, block);
        }

        long elapsed = now - instance.getLastProcessedAt();
        if (elapsed < intervalMillis) {
            return;
        }

        long cycles = elapsed / intervalMillis;
        if (cycles <= 0L) {
            return;
        }

        long totalRolls = cycles * definition.baseItemsPerCycle() * Math.max(1L, instance.getStackAmount());
        boolean changed = false;

        if (xpEnabled) {
            double xpGenerated = cycles * definition.xpPerCycle() * Math.max(1L, instance.getStackAmount());
            if (xpGenerated > 0.0) {
                instance.addStoredXp(xpGenerated);
                changed = true;
            }
        }

        if (totalRolls <= 0L) {
            instance.setLastProcessedAt(now);
            if (!isTemporarySpawner(instance)) {
                saveSpawnerAsync(instance);
            }
            return;
        }
        for (SpawnerTypeDefinition.DropDefinition drop : definition.drops()) {
            if (instance.isLootDisabled(drop.key())) {
                continue;
            }
            double expected = totalRolls * drop.chance() * drop.averageDropAmount();
            long generated = (long) Math.floor(expected);
            double remainder = expected - generated;
            if (remainder > 0D && ThreadLocalRandom.current().nextDouble() < remainder) {
                generated++;
            }

            if (generated <= 0L) {
                continue;
            }

            instance.addAutoMobDrop(drop.material(), generated, storageCapPerLootKey);
            changed = true;
        }

        instance.setLastProcessedAt(instance.getLastProcessedAt() + (cycles * intervalMillis));
        instance.setUpdatedAt(now);
        if (!isTemporarySpawner(instance)) {
            saveSpawnerAsync(instance);
        }
        if (changed) {
            saveLoot(instance);
        }
    }

    private void tryHopperExtraction(SpawnerInstance instance, Block block) {
        Block blockBelow = block.getRelative(BlockFace.DOWN);
        if (blockBelow.getType() != Material.HOPPER) {
            return;
        }

        org.bukkit.block.BlockState state = blockBelow.getState();
        if (!(state instanceof Hopper hopper)) {
            return;
        }

        Inventory hopperInventory = hopper.getInventory();
        boolean changed = false;

        List<SpawnerLootEntry> entries = new ArrayList<>(instance.getStoredLootEntries());
        for (SpawnerLootEntry entry : entries) {
            long storedAmount = entry.getAmount();
            if (storedAmount <= 0L) {
                continue;
            }

            Material material = entry.getMaterial();
            int maxStack = material.getMaxStackSize();
            long amountToTransfer = Math.min(storedAmount, Math.min(maxStack, hopperExtractionAmountPerCycle));
            if (amountToTransfer <= 0) {
                continue;
            }

            ItemStack itemToAdd = new ItemStack(material, (int) amountToTransfer);
            Map<Integer, ItemStack> remaining = hopperInventory.addItem(itemToAdd);
            int addedAmount = itemToAdd.getAmount();
            if (!remaining.isEmpty()) {
                addedAmount -= remaining.get(0).getAmount();
            }

            if (addedAmount > 0) {
                instance.removeStoredLoot(entry.getKey(), addedAmount);
                changed = true;
            }

            if (hopperInventory.firstEmpty() == -1 && !remaining.isEmpty()) {
                break;
            }
        }

        if (changed) {
            if (!isTemporarySpawner(instance)) {
                saveSpawnerAsync(instance);
            }
            saveLoot(instance);
        }
    }

    public String getStorageTitle(SpawnerInstance instance, int page, int maxPage) {
        if (instance == null) {
            return "&8Spawner storage";
        }
        String cleanMob = prettifyKey(instance.getMobTypeKey());
        String title = storageTitle
                .replace("{mob}", cleanMob)
                .replace("{page}", String.valueOf(page))
                .replace("{max_page}", String.valueOf(maxPage));

        title = title.replaceAll("(?i)\\bspawners?\\s+spawners?\\b", "Spawners");
        return title.length() > 32 ? title.substring(0, 32) : title;
    }

    public int getStorageSize() {
        return storageSize;
    }

    public int getStorageItemsPerPage() {
        return storageItemsPerPage;
    }

    public String getPanelTitle(String worldName) {
        String title = panelTitle.replace("{world}", describeWorld(worldName));
        return title.length() > 32 ? title.substring(0, 32) : title;
    }

    public int getPanelSize() {
        return panelSize;
    }

    public String getWorldListTitle() {
        return worldListTitle;
    }

    public int getWorldListSize() {
        return worldListSize;
    }

    public String describeWorld(String worldName) {
        if (worldName == null || worldName.isBlank()) {
            return "unknown";
        }

        return switch (worldName.trim().toLowerCase(Locale.US)) {
            case "world", "overworld" -> "overworld";
            case "world_nether", "nether" -> "nether";
            case "world_the_end", "the_end", "the-end", "end" -> "the end";
            default -> prettifyLabel(worldName);
        };
    }

    public Location getSpawnerCenter(SpawnerInstance instance) {
        World world = Bukkit.getWorld(instance.getWorld());
        return world == null
                ? new Location(Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().getFirst(), 0, 0, 0)
                : new Location(world, instance.getX() + 0.5D, instance.getY() + 0.5D, instance.getZ() + 0.5D);
    }

    public boolean canOpen(Player player, SpawnerInstance instance) {
        if (player == null || instance == null) {
            return false;
        }
        if (allowSpawnerSteal) {
            return true;
        }
        if (PermissionUtils.has(player, "ultimatedonutsmp.admin.spawner")) {
            return true;
        }
        if (player.getUniqueId().equals(instance.getOwnerUuid())) {
            return true;
        }

        return switch (instance.getAccessMode()) {
            case PUBLIC -> true;
            case OWNER_AND_TEAM -> plugin.getTeamManager().areTeammates(player.getUniqueId(), instance.getOwnerUuid());
            case OWNER_ONLY -> false;
        };
    }

    public boolean canBreak(Player player, SpawnerInstance instance) {
        if (player == null || instance == null) {
            return false;
        }
        if (allowSpawnerSteal) {
            return true;
        }
        if (PermissionUtils.has(player, "ultimatedonutsmp.admin.spawner")) {
            return true;
        }
        if (player.getUniqueId().equals(instance.getOwnerUuid())) {
            return true;
        }

        return switch (instance.getAccessMode()) {
            case PUBLIC -> true;
            case OWNER_AND_TEAM -> plugin.getTeamManager().areTeammates(player.getUniqueId(), instance.getOwnerUuid());
            case OWNER_ONLY -> false;
        };
    }

    public boolean canModify(Player player, SpawnerInstance instance) {
        return canOpen(player, instance);
    }

    public void setServerWipeMode(boolean serverWipeMode) {
        this.serverWipeMode = serverWipeMode;
    }

    public void shutdown() {
        if (serverWipeMode) {
            return;
        }
        List<SpawnerInstance> copy;
        synchronized (lock) {
            copy = new ArrayList<>(spawnersById.values());
        }
        for (SpawnerInstance instance : copy) {
            if (isTemporarySpawner(instance)) {
                continue;
            }
            plugin.getDatabaseManager().saveSpawner(instance);
            List<SpawnerLootEntry> lootCopy = new ArrayList<>(instance.getStoredLootEntries());
            plugin.getDatabaseManager().replaceSpawnerLoot(instance.getId(), lootCopy);
        }
    }

    private long moveMaterialToInventory(PlayerInventory inventory, Material material, long amount) {
        if (inventory == null || material == null || amount <= 0L) {
            return 0L;
        }

        long remaining = amount;
        long moved = 0L;
        int maxStack = material.getMaxStackSize();

        while (remaining > 0L) {
            int stackAmount = (int) Math.min(maxStack, remaining);
            ItemStack stack = new ItemStack(material, stackAmount);
            Map<Integer, ItemStack> leftovers = inventory.addItem(stack);
            if (leftovers.isEmpty()) {
                moved += stackAmount;
                remaining -= stackAmount;
                continue;
            }

            int leftoverAmount = leftovers.values().stream().mapToInt(ItemStack::getAmount).sum();
            int insertedAmount = stackAmount - leftoverAmount;
            moved += Math.max(0L, insertedAmount);
            break;
        }

        return moved;
    }

    private long dropMaterial(Player player, Location location, Material material, long amount) {
        if (material == null || amount <= 0L) {
            return 0L;
        }

        World world;
        Location spawnLoc;
        org.bukkit.util.Vector velocity = null;

        if (player != null && player.isOnline()) {
            world = player.getWorld();
            spawnLoc = player.getLocation().add(0, 1.2, 0);
            velocity = player.getLocation().getDirection().normalize().multiply(0.35D);
        } else if (location != null && location.getWorld() != null) {
            world = location.getWorld();
            spawnLoc = location;
        } else {
            return 0L;
        }

        long remaining = amount;
        long dropped = 0L;
        int maxStack = material.getMaxStackSize();

        while (remaining > 0L) {
            int stackAmount = (int) Math.min(maxStack, remaining);
            org.bukkit.entity.Item droppedItem = world.dropItem(spawnLoc, new ItemStack(material, stackAmount));
            if (velocity != null) {
                droppedItem.setVelocity(velocity);
            }
            dropped += stackAmount;
            remaining -= stackAmount;
        }
        return dropped;
    }

    private boolean hasNearbyPlayer(World world, SpawnerInstance instance, double radius) {
        double radiusSquared = radius * radius;
        Location center = new Location(world, instance.getX() + 0.5D, instance.getY() + 0.5D, instance.getZ() + 0.5D);
        for (Player player : world.getPlayers()) {
            if (player.getLocation().distanceSquared(center) <= radiusSquared) {
                return true;
            }
        }
        return false;
    }

    public void deleteSpawnerAsync(long spawnerId) {
        if (spawnerId <= 0L) {
            return;
        }
        plugin.getDatabaseManager().executeAsync(() -> {
            plugin.getDatabaseManager().deleteSpawner(spawnerId);
        });
    }

    public void saveSpawnerAsync(SpawnerInstance instance) {
        if (instance == null || isTemporarySpawner(instance)) {
            return;
        }
        plugin.getDatabaseManager().executeAsync(() -> {
            plugin.getDatabaseManager().saveSpawner(instance);
        });
    }

    public void saveLoot(SpawnerInstance instance) {
        if (instance == null || isTemporarySpawner(instance)) {
            return;
        }
        long spawnerId = instance.getId();
        List<SpawnerLootEntry> latestLoot = new ArrayList<>(instance.getStoredLootEntries());
        boolean isFirst = (pendingLootMap.put(spawnerId, latestLoot) == null);
        if (isFirst) {
            plugin.getDatabaseManager().executeAsync(() -> {
                List<SpawnerLootEntry> toSave = pendingLootMap.remove(spawnerId);
                if (toSave != null) {
                    plugin.getDatabaseManager().replaceSpawnerLoot(spawnerId, toSave);
                }
            });
        }
    }

    public void saveSpawnerAndLoot(SpawnerInstance instance) {
        if (instance == null || isTemporarySpawner(instance)) {
            return;
        }
        saveSpawnerAsync(instance);
        saveLoot(instance);
    }

    private void registerSpawner(SpawnerInstance instance) {
        synchronized (lock) {
            spawnersById.put(instance.getId(), instance);
            locationIndex.put(instance.getLocationKey(), instance.getId());
            worldIndex.computeIfAbsent(instance.getWorld().toLowerCase(Locale.US), ignored -> new LinkedHashSet<>())
                    .add(instance.getId());
        }
    }

    private void unregisterSpawner(SpawnerInstance instance) {
        synchronized (lock) {
            spawnersById.remove(instance.getId());
            locationIndex.remove(instance.getLocationKey());
            LinkedHashSet<Long> ids = worldIndex.get(instance.getWorld().toLowerCase(Locale.US));
            if (ids != null) {
                ids.remove(instance.getId());
                if (ids.isEmpty()) {
                    worldIndex.remove(instance.getWorld().toLowerCase(Locale.US));
                }
            }
        }
    }

    public Material getWorldIcon(World world) {
        if (world == null) {
            return Material.GRASS_BLOCK;
        }

        return switch (world.getEnvironment()) {
            case NETHER -> Material.NETHERRACK;
            case THE_END -> Material.END_STONE;
            default -> Material.GRASS_BLOCK;
        };
    }

    private int getWorldSortIndex(String worldName) {
        if (worldName == null || worldName.isBlank()) {
            return Integer.MAX_VALUE;
        }

        return switch (worldName.trim().toLowerCase(Locale.US)) {
            case "world", "overworld" -> 0;
            case "world_nether", "nether" -> 1;
            case "world_the_end", "the_end", "the-end", "end" -> 2;
            default -> 10;
        };
    }

    private ActionResult ok(String message) {
        return new ActionResult(true, message);
    }

    private ActionResult fail(String message) {
        return new ActionResult(false, message);
    }

    private SellLootResult failSell(String message) {
        return new SellLootResult(false, message, 0D, 0L);
    }

    public void syncSpawnerBlockState(SpawnerInstance instance) {
        if (instance == null) {
            return;
        }

        World world = Bukkit.getWorld(instance.getWorld());
        if (world == null) {
            return;
        }

        int chunkX = instance.getX() >> 4;
        int chunkZ = instance.getZ() >> 4;
        if (!plugin.getSpigotScheduler().isFolia() && Bukkit.isPrimaryThread()) {
            if (!world.isChunkLoaded(chunkX, chunkZ)) {
                return;
            }
            syncSpawnerBlockStateImmediate(instance);
            return;
        }

        plugin.getSpigotScheduler().runRegion(
                world,
                chunkX,
                chunkZ,
                () -> syncSpawnerBlockStateImmediate(instance)
        );
    }

    private void syncSpawnerBlockStateImmediate(SpawnerInstance instance) {
        if (instance == null) {
            return;
        }

        World world = Bukkit.getWorld(instance.getWorld());
        if (world == null) {
            return;
        }

        if (!world.isChunkLoaded(instance.getX() >> 4, instance.getZ() >> 4)) {
            return;
        }

        SpawnerTypeDefinition definition = getTypeDefinition(instance.getMobTypeKey());
        if (definition == null) {
            return;
        }

        Block block = world.getBlockAt(instance.getX(), instance.getY(), instance.getZ());
        if (block.getType() != Material.SPAWNER) {
            return;
        }

        if (!(block.getState() instanceof CreatureSpawner spawnerState)) {
            return;
        }

        boolean updated = false;
        if (spawnerState.getSpawnedType() != definition.entityType()) {
            spawnerState.setSpawnedType(definition.entityType());
            updated = true;
        }

        if (spawnerState.getDelay() > 800 || spawnerState.getDelay() < 200) {
            spawnerState.setMinSpawnDelay(200);
            spawnerState.setMaxSpawnDelay(800);
            spawnerState.setDelay(200);
            updated = true;
        }

        if (updated) {
            spawnerState.update(true, true);
        }
    }

    /**
     * Placing a spawner in creative costs nothing, so breaking one must not hand a spawner back:
     * paying out either way turned a creative break into a free spawner item. The two halves of
     * that rule live here together so they cannot drift apart again.
     */
    static boolean consumesSpawnerItemOnPlace(GameMode gameMode) {
        return gameMode != GameMode.CREATIVE;
    }

    static boolean returnsSpawnerItemOnBreak(GameMode gameMode) {
        return gameMode != GameMode.CREATIVE;
    }

    public void consumeHeldSpawnerItem(Player player, boolean all) {
        if (player == null || !consumesSpawnerItemOnPlace(player.getGameMode())) {
            return;
        }

        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            return;
        }

        consumeHeldSpawnerItem(player, all ? hand.getAmount() : 1);
    }

    public void consumeHeldSpawnerItem(Player player, int amount) {
        if (player == null || !consumesSpawnerItemOnPlace(player.getGameMode()) || amount <= 0) {
            return;
        }

        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            return;
        }

        int nextAmount = hand.getAmount() - amount;
        if (nextAmount <= 0) {
            player.getInventory().setItemInMainHand(null);
            return;
        }

        hand.setAmount(nextAmount);
        player.getInventory().setItemInMainHand(hand);
    }

    public String prettifyKey(String key) {
        if (key == null || key.isBlank()) {
            return "Spawner";
        }

        return prettifyLabel(key);
    }

    private String prettifyLabel(String value) {
        if (value == null || value.isBlank()) {
            return "unknown";
        }

        String[] tokens = value.toLowerCase(Locale.US).replace('-', '_').split("_");
        StringBuilder builder = new StringBuilder();
        for (String token : tokens) {
            if (token.isBlank()) {
                continue;
            }
            if (!builder.isEmpty()) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(token.charAt(0))).append(token.substring(1));
        }
        return builder.toString();
    }

    public Material getTypeIcon(String typeKey) {
        SpawnerTypeDefinition def = getTypeDefinition(typeKey);
        return def == null || def.iconMaterial() == null ? Material.SPAWNER : def.iconMaterial();
    }

    public int normalizeSize(int size) {
        int normalized = Math.max(9, ((size + 8) / 9) * 9);
        return Math.min(54, normalized);
    }
}
